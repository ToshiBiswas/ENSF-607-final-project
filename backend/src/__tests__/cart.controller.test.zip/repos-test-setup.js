// backend/src/__tests__/repos-test-setup.js
// Add this file to jest.config.js -> setupFilesAfterEnv

const makeFnMap = (keys) => {
  const map = {};
  keys.forEach(k => (map[k] = jest.fn()));
  // expose a local reset for convenience
  map.__reset = () => keys.forEach(k => map[k].mockReset());
  return map;
};

jest.mock('../../repos/EventRepo', () => {
  const fns = makeFnMap([
    'create','findById','update','remove','list','listByCategoryName'
  ]);
  return { __esModule: true, ...fns, _state: fns };
});

jest.mock('../../repos/CategoryRepo', () => {
  const fns = makeFnMap(['list','findByName','ensureMany']);
  return { __esModule: true, ...fns, _state: fns };
});

jest.mock('../../repos/TicketInfoRepo', () => {
  const fns = makeFnMap(['listByEvent','upsertMany','incrementStock']);
  return { __esModule: true, ...fns, _state: fns };
});

jest.mock('../../repos/TicketMintRepo', () => {
  const fns = makeFnMap(['mintMany','listByUser']);
  return { __esModule: true, ...fns, _state: fns };
});

jest.mock('../../repos/UserRepo', () => {
  const fns = makeFnMap(['create','findByEmail','findById','update']);
  return { __esModule: true, ...fns, _state: fns };
});

jest.mock('../../repos/UserPreferencesRepo', () => {
  const fns = makeFnMap(['getByUserId','setForUser']);
  return { __esModule: true, ...fns, _state: fns };
});

jest.mock('../../repos/PaymentInfoRepo', () => {
  const fns = makeFnMap(['listByUser','saveForUser','removeForUser']);
  return { __esModule: true, ...fns, _state: fns };
});

jest.mock('../../repos/PaymentRepo', () => {
  const fns = makeFnMap(['create','findById','refund']);
  return { __esModule: true, ...fns, _state: fns };
});

jest.mock('../../repos/NotificationRepo', () => {
  const fns = makeFnMap(['listByUser','markRead','create']);
  return { __esModule: true, ...fns, _state: fns };
});

// Helpers you can call from tests to reset/tweak:
global.__repos = {
  resetAll() {
    const mods = [
      require('../../repos/EventRepo'),
      require('../../repos/CategoryRepo'),
      require('../../repos/TicketInfoRepo'),
      require('../../repos/TicketMintRepo'),
      require('../../repos/UserRepo'),
      require('../../repos/UserPreferencesRepo'),
      require('../../repos/PaymentInfoRepo'),
      require('../../repos/PaymentRepo'),
      require('../../repos/NotificationRepo'),
    ];
    mods.forEach(m => m._state.__reset());
  },
};
