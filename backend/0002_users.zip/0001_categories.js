// seeds/0001_categories.js
/** @param {import('knex').Knex} knex */
exports.seed = async (knex) => {
  // Clean M2M first to avoid FK conflicts when truncating categories
  const hasEC = await knex.schema.hasTable('eventscategories');
  if (hasEC) await knex('eventscategories').del();

  const hasCat = await knex.schema.hasTable('categories');
  if (!hasCat) return; // migration not run yet

  await knex('categories').del();

  await knex('categories').insert(
    [
      'Technology',
      'Music',
      'Food & Drink',
      'Wellness',
      'Sports',
      'Arts & Culture',
    ].map((category_value) => ({ category_value }))
  );
};
