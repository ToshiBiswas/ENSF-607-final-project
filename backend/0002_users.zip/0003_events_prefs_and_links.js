// seeds/0003_events_prefs_and_links.js
// Seeds events (with ticket_type), event↔category links, user preferences (string category),
// ticketinfo (inventory), tickets (with 6-char code), payments, notifications.

/** 6-char uppercase alphanumeric ticket version */
function genTicketVersion() {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let out = '';
  for (let i = 0; i < 6; i++) out += chars[Math.floor(Math.random() * chars.length)];
  return out;
}

/** @param {import('knex').Knex} knex */
exports.seed = async (knex) => {
  // --- helpers ---------------------------------------------------------------
  const catId = async (label) => {
    // FIX: use the correct table name "categories" (NOT "categoriesid")
    const row = await knex('categories').where({ category_value: label }).first();
    if (!row) throw new Error(`Category not found: ${label}`);
    return row.category_id;
  };

  // --- users -----------------------------------------------------------------
  const users = await knex('users').select('user_id', 'name').orderBy('user_id');
  if (!users.length) return;

  const admin = users.find(u => u.name === 'Admin')?.user_id ?? users[0].user_id;
  const ava   = users.find(u => u.name === 'Ava Patel')?.user_id;
  const liam  = users.find(u => u.name === 'Liam Chen')?.user_id;
  const sofia = users.find(u => u.name === 'Sofia Garcia')?.user_id;

  // --- events (KEEP ticket_type) --------------------------------------------
  const [hackathonId] = await knex('events').insert({
    organizer_id: admin,
    title: 'Calgary AI Mini-Hack',
    description: 'A 6-hour hands-on hack focused on LLM tooling and data pipelines.',
    location: 'Platform Calgary, 407 9 Ave SE',
    start_time: knex.raw('NOW() + INTERVAL 5 DAY'),
    end_time:   knex.raw('NOW() + INTERVAL 5 DAY + INTERVAL 6 HOUR'),
    ticket_type: 'general',
  });

  const [parkFestId] = await knex('events').insert({
    organizer_id: admin,
    title: 'Riverside Music & Food Fest',
    description: 'Local bands, craft vendors, and pop-up food stalls by the river.',
    location: 'Prince’s Island Park',
    start_time: knex.raw('NOW() + INTERVAL 12 DAY'),
    end_time:   knex.raw('NOW() + INTERVAL 12 DAY + INTERVAL 8 HOUR'),
    ticket_type: 'vip',
  });

  const [wellnessId] = await knex('events').insert({
    organizer_id: admin,
    title: 'Sunrise Yoga & Smoothies',
    description: 'Group vinyasa session followed by a nutrition chat and smoothies.',
    location: 'Central Memorial Park',
    start_time: knex.raw('NOW() + INTERVAL 3 DAY'),
    end_time:   knex.raw('NOW() + INTERVAL 3 DAY + INTERVAL 90 MINUTE'),
    ticket_type: 'general',
  });

  // --- event ↔ categories (many-to-many) ------------------------------------
  await knex('eventscategories').insert([
    { event_id: hackathonId, category_id: await catId('Technology') },
    { event_id: parkFestId,  category_id: await catId('Music') },
    { event_id: parkFestId,  category_id: await catId('Food & Drink') },
    { event_id: wellnessId,  category_id: await catId('Wellness') },
  ]);

  // --- user preferences (ONE per user; string category) ----------------------
  // If you have a unique index on user_id, this will upsert.
  await knex('userpreferences')
    .insert([
      ...(ava   ? [{ user_id: ava,   location: 'Downtown Calgary', category: 'Technology' }] : []),
      ...(liam  ? [{ user_id: liam,  location: 'Beltline',         category: 'Music' }]      : []),
      ...(sofia ? [{ user_id: sofia, location: 'Kensington',       category: 'Wellness' }]   : []),
    ])
    .onConflict('user_id').merge();

  // --- ticketinfo (inventory per event/type) --------------------------------
  const [hackGeneralId] = await knex('ticketinfo').insert({
    event_id: hackathonId,
    ticket_type: 'general',
    ticket_price: 25.00,
    tickets_quantity: 120,
    tickets_left: 120,
  });

  const [parkVipId] = await knex('ticketinfo').insert({
    event_id: parkFestId,
    ticket_type: 'vip',
    ticket_price: 99.00,
    tickets_quantity: 50,
    tickets_left: 50,
  });

  const [yogaGeneralId] = await knex('ticketinfo').insert({
    event_id: wellnessId,
    ticket_type: 'general',
    ticket_price: 15.00,
    tickets_quantity: 60,
    tickets_left: 60,
  });

  // --- tickets (create first, capture IDs) -----------------------------------
  const now = knex.fn.now();

  const [t1] = await knex('tickets').insert({
    event_id: hackathonId,
    user_id: ava ?? admin,
    ticket_type: 'general',
    ticket_version: genTicketVersion(),
    price: 25.00,
    purchase_date: now,
    ticket_info_id: hackGeneralId,
  });

  const [t2] = await knex('tickets').insert({
    event_id: parkFestId,
    user_id: liam ?? admin,
    ticket_type: 'vip',
    ticket_version: genTicketVersion(),
    price: 99.00,
    purchase_date: now,
    ticket_info_id: parkVipId,
  });

  const [t3] = await knex('tickets').insert({
    event_id: wellnessId,
    user_id: sofia ?? admin,
    ticket_type: 'general',
    ticket_version: genTicketVersion(),
    price: 15.00,
    purchase_date: now,
    ticket_info_id: yogaGeneralId,
  });

  // --- payments (now t1/t2/t3 are defined) -----------------------------------
  await knex('payments').insert([
    { ticket_id: t1, amount: 25.00, status: 'paid',    payment_date: knex.raw('NOW() + INTERVAL 1 DAY') },
    { ticket_id: t2, amount: 99.00, status: 'paid',    payment_date: knex.raw('NOW() + INTERVAL 2 DAY') },
    { ticket_id: t3, amount: 15.00, status: 'pending', payment_date: knex.raw('NOW() + INTERVAL 1 DAY') },
  ]);

  // --- notifications ----------------------------------------------------------
  if (ava) {
    await knex('notifications').insert({
      user_id: ava,
      event_id: hackathonId,
      message: 'You’re in! See you at Calgary AI Mini-Hack.',
      sent_at: knex.raw('NOW() + INTERVAL 1 DAY'),
    });
  }
  if (liam) {
    await knex('notifications').insert({
      user_id: liam,
      event_id: parkFestId,
      message: 'VIP access confirmed for Riverside Music Fest.',
      sent_at: knex.raw('NOW() + INTERVAL 2 DAY'),
    });
  }
  if (sofia) {
    await knex('notifications').insert({
      user_id: sofia,
      event_id: wellnessId,
      message: 'Your spot is reserved for Sunrise Yoga.',
      sent_at: knex.raw('NOW() + INTERVAL 1 DAY'),
    });
  }
};
